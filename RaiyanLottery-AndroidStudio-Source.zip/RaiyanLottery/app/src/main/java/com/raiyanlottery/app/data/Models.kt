package com.raiyanlottery.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "agents")
data class Agent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)

/** ISSUE = tickets delivered; RETURN = unsold tickets returned; PAYMENT = money collected. */
@Entity(tableName = "ledger_entries")
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agentId: Long,
    val type: String,
    val ticketCount: Int = 0,
    val amount: Double = 0.0,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)
