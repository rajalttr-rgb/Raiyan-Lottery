package com.raiyanlottery.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface LotteryDao {
    @Query("SELECT * FROM agents ORDER BY name COLLATE NOCASE") fun observeAgents(): Flow<List<Agent>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addAgent(agent: Agent): Long
    @Query("SELECT * FROM ledger_entries WHERE agentId = :agentId ORDER BY createdAt DESC") fun observeLedger(agentId: Long): Flow<List<LedgerEntry>>
    @Query("SELECT * FROM ledger_entries ORDER BY createdAt DESC") fun observeAllLedger(): Flow<List<LedgerEntry>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addEntry(entry: LedgerEntry): Long
    @Query("SELECT * FROM agents WHERE id = :id LIMIT 1") suspend fun getAgent(id: Long): Agent?
}

@Database(entities = [Agent::class, LedgerEntry::class], version = 1, exportSchema = false)
abstract class LotteryDatabase : RoomDatabase() {
    abstract fun dao(): LotteryDao
    companion object {
        @Volatile private var INSTANCE: LotteryDatabase? = null
        fun get(context: Context): LotteryDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, LotteryDatabase::class.java, "raiyan_lottery.db").build().also { INSTANCE = it }
        }
    }
}
