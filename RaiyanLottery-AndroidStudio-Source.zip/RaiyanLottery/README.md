# Raiyan Lottery — Android Studio source project

Premium red/black/gold starter app for tracking lottery-agent ticket ledger. The app is a working **offline-first MVP source project**; it is not yet a signed APK or a production cloud-synced release.

## Current features
- Add an unlimited number of agents (name and phone).
- Agent-wise ledger entries: tickets issued, tickets returned, and payments received.
- Local Room database: entries remain on the device when offline and after app restart.
- Dashboard totals for issued/returned ticket counts and an estimated overall due balance.
- Bengali/English UI toggle.
- Premium wine-red, black and gold styling.

## Important accounting note
For ISSUE and RETURN entries, enter the **money value** represented by that transaction in the Amount field. Due = issue amount − return amount − payment received. This MVP does not infer ticket value, commission, draw, series or ticket-number details. Confirm business rules before relying on reports for actual settlement.

## Open in Android Studio
1. Install Android Studio with JDK 17 and Android SDK 35.
2. Open this `RaiyanLottery` folder.
3. Allow Gradle sync to finish; internet is needed to download dependencies.
4. Run on an Android 8.0+ device/emulator.

The source project has not been built or tested in this environment. Resolve any Android Studio/Gradle errors before using with live business data.

## Enable Firebase cloud sync (not active yet)
Offline Room storage is implemented. Cloud sync is **not active** until you configure a Firebase project and implement a sync worker. Recommended next steps:
1. Create a Firebase project and register package `com.raiyanlottery.app`.
2. Add `google-services.json` to `app/`, add Google Services and Firebase BoM/Firestore dependencies using current official Firebase Android instructions.
3. Enable Firebase Authentication and Cloud Firestore security rules; do not use public read/write rules.
4. Implement a WorkManager-based outbox sync for rows where `syncPending = true`, with stable IDs, conflict handling and per-user authorization. Mark records synced only after a confirmed server write.
5. Test airplane-mode entry, reconnect/retry, duplicate prevention, restore and multi-device conflict cases.

## Suggested production hardening
- Add owner login/PIN and encrypted backup.
- Add edit/reversal audit trail instead of deleting financial entries.
- Add configurable ticket price/commission and a date/draw-wise report.
- Validate returns against tickets issued; add CSV/PDF export and database backup/restore.
- Verify local lottery-business rules and permitted recordkeeping before deployment.
