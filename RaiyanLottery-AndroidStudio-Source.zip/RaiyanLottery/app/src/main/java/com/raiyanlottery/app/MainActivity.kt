package com.raiyanlottery.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.raiyanlottery.app.data.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Wine = Color(0xFF650D19)
private val Red = Color(0xFFB51F2B)
private val Gold = Color(0xFFD6AE52)
private val Ink = Color(0xFF171316)
private val SurfaceDark = Color(0xFF241D20)

class MainActivity : ComponentActivity() {
    private val dao by lazy { LotteryDatabase.get(this).dao() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Red, background = Ink, surface = SurfaceDark, onPrimary = Ink)) { LotteryApp(dao) } }
    }
}

@Composable
private fun LotteryApp(dao: LotteryDao) {
    var bengali by remember { mutableStateOf(true) }
    var agents by remember { mutableStateOf(emptyList<Agent>()) }
    var allEntries by remember { mutableStateOf(emptyList<LedgerEntry>()) }
    var selectedAgent by remember { mutableStateOf<Agent?>(null) }
    var showAgentDialog by remember { mutableStateOf(false) }
    var entryType by remember { mutableStateOf("ISSUE") }
    var showEntryDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bn = bengali
    fun label(en: String, bangla: String) = if (bn) bangla else en
    LaunchedEffect(Unit) {
        launch { dao.observeAgents().collectLatest { agents = it } }
        launch { dao.observeAllLedger().collectLatest { allEntries = it } }
    }
    val totalIssued = allEntries.filter { it.type == "ISSUE" }.sumOf { it.ticketCount }
    val totalReturned = allEntries.filter { it.type == "RETURN" }.sumOf { it.ticketCount }
    val totalPaid = allEntries.filter { it.type == "PAYMENT" }.sumOf { it.amount }
    val totalDue = allEntries.filter { it.type == "ISSUE" }.sumOf { it.amount } - allEntries.filter { it.type == "RETURN" }.sumOf { it.amount } - totalPaid

    Scaffold(containerColor = Ink, topBar = {
        Column(Modifier.fillMaxWidth().background(Wine).padding(horizontal = 18.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("RY", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    Text("Raiyan Lottery", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text(label("Agent & Ticket Ledger", "এজেন্ট ও টিকিটের হিসাব"), color = Color(0xFFE9D9D9), fontSize = 12.sp)
                }
                IconButton(onClick = { bengali = !bengali }) { Icon(Icons.Default.Language, contentDescription = "Language", tint = Gold) }
                Text(if (bengali) "BN" else "EN", color = Gold, fontWeight = FontWeight.Bold)
            }
        }
    }, floatingActionButton = {
        FloatingActionButton(onClick = { if (selectedAgent == null) showAgentDialog = true else { entryType = "ISSUE"; showEntryDialog = true } }, containerColor = Gold, contentColor = Ink) { Icon(Icons.Default.Add, contentDescription = "Add") }
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MetricCard(label("Issued", "দেওয়া টিকিট"), totalIssued.toString(), Modifier.weight(1f))
                MetricCard(label("Returned", "ফেরত টিকিট"), totalReturned.toString(), Modifier.weight(1f))
                MetricCard(label("Due ₹", "বকেয়া ₹"), money(totalDue), Modifier.weight(1f), true)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.People, tint = Gold, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(label("Agents", "এজেন্ট তালিকা"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showAgentDialog = true }) { Text(label("+ Add agent", "+ এজেন্ট যোগ"), color = Gold) }
            }
            if (selectedAgent != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedAgent = null }) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Gold) }
                    Column(Modifier.weight(1f)) {
                        Text(selectedAgent!!.name, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(selectedAgent!!.phone, color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActionChip(label("Give tickets", "টিকিট দিন")) { entryType = "ISSUE"; showEntryDialog = true }
                    ActionChip(label("Return", "ফেরত")) { entryType = "RETURN"; showEntryDialog = true }
                    ActionChip(label("Payment", "টাকা জমা")) { entryType = "PAYMENT"; showEntryDialog = true }
                }
                var ledger by remember { mutableStateOf(emptyList<LedgerEntry>()) }
                LaunchedEffect(selectedAgent?.id) { selectedAgent?.let { a -> dao.observeLedger(a.id).collectLatest { ledger = it } } }
                Text(label("Recent transactions", "সাম্প্রতিক লেনদেন"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
                LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ledger, key = { it.id }) { e -> EntryCard(e, bn) }
                }
            } else {
                if (agents.isEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Gold, modifier = Modifier.size(46.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(label("No agents yet", "এখনও কোনো এজেন্ট যোগ করা হয়নি"), color = Color.White, fontWeight = FontWeight.Bold)
                        Text(label("Tap + Add agent to get started.", "+ এজেন্ট যোগ বোতামে চাপ দিয়ে শুরু করুন।"), color = Color.LightGray, fontSize = 12.sp)
                    }
                } else LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(agents, key = { it.id }) { a ->
                        val entries = allEntries.filter { it.agentId == a.id }
                        val due = entries.filter { it.type == "ISSUE" }.sumOf { it.amount } - entries.filter { it.type == "RETURN" }.sumOf { it.amount } - entries.filter { it.type == "PAYMENT" }.sumOf { it.amount }
                        AgentCard(a, due, bn) { selectedAgent = a }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Color(0xFF56C58A), RoundedCornerShape(50)))
                Spacer(Modifier.width(8.dp))
                Text(label("Offline data saved on this device", "অফলাইন হিসাব এই ডিভাইসে সেভ হচ্ছে"), color = Color.LightGray, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("v1.0.0", color = Gold, fontSize = 11.sp)
            }
        }
    }
    if (showAgentDialog) AgentDialog(bn, onDismiss = { showAgentDialog = false }) { name, phone ->
        scope.launch { dao.addAgent(Agent(name = name.trim(), phone = phone.trim())) }
        showAgentDialog = false
    }
    if (showEntryDialog && selectedAgent != null) EntryDialog(bn, entryType, onDismiss = { showEntryDialog = false }) { tickets, amount, note ->
        scope.launch { dao.addEntry(LedgerEntry(agentId = selectedAgent!!.id, type = entryType, ticketCount = tickets, amount = amount, note = note.trim())) }
        showEntryDialog = false
    }
}

@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier, alert: Boolean = false) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(11.dp)) { Text(title, color = Color.LightGray, fontSize = 10.sp); Spacer(Modifier.height(6.dp)); Text(value, color = if (alert) Gold else Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold) }
    }
}
@Composable private fun AgentCard(agent: Agent, due: Double, bn: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Wine, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(agent.name.take(1).uppercase(), color = Gold, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(agent.name, color = Color.White, fontWeight = FontWeight.Bold); Text(agent.phone.ifBlank { if (bn) "ফোন নম্বর নেই" else "No phone" }, color = Color.LightGray, fontSize = 12.sp) }
            Column(horizontalAlignment = Alignment.End) { Text(if (bn) "বকেয়া" else "DUE", color = Color.LightGray, fontSize = 10.sp); Text("₹${money(due)}", color = if (due > 0) Gold else Color(0xFF72D39A), fontWeight = FontWeight.Bold) }
        }
    }
}
@Composable private fun EntryCard(e: LedgerEntry, bn: Boolean) {
    val typeLabel = when(e.type) { "ISSUE" -> if (bn) "টিকিট দেওয়া" else "Tickets issued"; "RETURN" -> if (bn) "টিকিট ফেরত" else "Tickets returned"; else -> if (bn) "টাকা জমা" else "Payment received" }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(typeLabel, color = Color.White, fontWeight = FontWeight.SemiBold); Text(SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(e.createdAt)), color = Color.LightGray, fontSize = 10.sp); if (e.note.isNotBlank()) Text(e.note, color = Color.LightGray, fontSize = 11.sp) }
            Column(horizontalAlignment = Alignment.End) { if (e.ticketCount > 0) Text("${e.ticketCount} ${if (bn) "টি" else "tickets"}", color = Gold, fontWeight = FontWeight.Bold); Text("₹${money(e.amount)}", color = Color.White, fontWeight = FontWeight.Bold) }
        }
    }
}
@Composable private fun ActionChip(text: String, onClick: () -> Unit) { Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Gold), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text(text, fontSize = 11.sp) } }

@Composable private fun AgentDialog(bn: Boolean, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = SurfaceDark, title = { Text(if (bn) "নতুন এজেন্ট" else "New agent", color = Gold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text(if (bn) "এজেন্টের নাম *" else "Agent name *") }, singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text(if (bn) "ফোন নম্বর" else "Phone number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name, phone) }, enabled = name.isNotBlank()) { Text(if (bn) "সেভ" else "Save", color = Gold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text(if (bn) "বাতিল" else "Cancel", color = Color.LightGray) } })
}
@Composable private fun EntryDialog(bn: Boolean, type: String, onDismiss: () -> Unit, onSave: (Int, Double, String) -> Unit) {
    var tickets by remember { mutableStateOf(if (type == "PAYMENT") "0" else "") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    val title = when(type) { "ISSUE" -> if (bn) "টিকিট দেওয়ার হিসাব" else "Issue tickets"; "RETURN" -> if (bn) "ফেরত টিকিটের হিসাব" else "Record return"; else -> if (bn) "টাকা জমা নিন" else "Record payment" }
    AlertDialog(onDismissRequest = onDismiss, containerColor = SurfaceDark, title = { Text(title, color = Gold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (type != "PAYMENT") OutlinedTextField(tickets, { tickets = it.filter(Char::isDigit) }, label = { Text(if (bn) "টিকিটের সংখ্যা *" else "Ticket count *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text(if (bn) "টাকার পরিমাণ (₹) *" else "Amount (₹) *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text(if (bn) "নোট (ঐচ্ছিক)" else "Note (optional)") }, singleLine = true)
            Text(if (bn) "টাকার পরিমাণ নিজে যাচাই করে লিখুন।" else "Enter and verify the amount manually.", color = Color.LightGray, fontSize = 11.sp)
        }
    }, confirmButton = { TextButton(onClick = { val t = tickets.toIntOrNull() ?: 0; val a = amount.toDoubleOrNull(); if (a != null && a >= 0 && (type == "PAYMENT" || t > 0)) onSave(t, a, note) }, enabled = amount.toDoubleOrNull() != null && (type == "PAYMENT" || (tickets.toIntOrNull() ?: 0) > 0)) { Text(if (bn) "সেভ" else "Save", color = Gold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text(if (bn) "বাতিল" else "Cancel", color = Color.LightGray) } })
}
private fun money(value: Double): String = String.format(Locale.US, "%,.2f", value).removeSuffix(".00")
